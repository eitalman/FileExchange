﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;


namespace UdpTester
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    class JoystickMessage : ICloneable
    {
        int x_axis_position_;                     /* x-axis position              */
		int y_axis_position_;                     /* y-axis position              */
		//int z_axis_position_;                     /* z-axis position              */
		//int x_axis_rotation_;                    /* x-axis rotation              */
		//int y_axis_rotation_;                    /* y-axis rotation              */
		//int z_axis_rotation_;                    /* z-axis rotation              */
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
		//int [] extra_axes_positions_ = new int[2];           /* extra axes positions         */
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
		//uint [] pov_directions_ = new uint[4];             /* POV directions               */
         //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        //byte[] buttons_ = new byte[32];         /* 32 buttons                   */
        int last_pressed_button_;

        enum JOYSTICK_MODE
        {
            AUTO = 0,
            MANUAL = 1
        };
     

        public override string ToString()
        {

            if (last_pressed_button_ == (int)JOYSTICK_MODE.AUTO)
            {
                return "\n x_axis_position_ : " + x_axis_position_ +
                  "\n y_axis_position_ : " + y_axis_position_ +
                    //"\n Z_axis_position_ : " + z_axis_position_ +
                    //"\n x_axis_rotation_ : " + x_axis_rotation_ +
                    //"\n y_axis_rotation_ : " + y_axis_rotation_ +
                    //"\n z_axis_rotation_ : " + z_axis_rotation_ +
                    //"\n extra_axes_positions_[0] : " + extra_axes_positions_[0] +
                    //"\n extra_axes_positions_[1] : " + extra_axes_positions_[1] +
                    //"\n pov_directions_[0] : " + pov_directions_[0] +
                    //"\n pov_directions_[1] : " + pov_directions_[1] +
                    //"\n pov_directions_[2] : " + pov_directions_[2] +
                    //"\n pov_directions_[3] : " + pov_directions_[3] +
                    //"\n buttons_[0] : " + buttons_[0] +
                    //"\n buttons_[1] : " + buttons_[1] +
                    //"\n buttons_[2] : " + buttons_[2]; 
                    "\n Auto";
            }
            else if (last_pressed_button_ == (int)JOYSTICK_MODE.MANUAL)
            {
                return "\n x_axis_position_ : " + x_axis_position_ +
                 "\n y_axis_position_ : " + y_axis_position_ +
                    //"\n Z_axis_position_ : " + z_axis_position_ +
                    //"\n x_axis_rotation_ : " + x_axis_rotation_ +
                    //"\n y_axis_rotation_ : " + y_axis_rotation_ +
                    //"\n z_axis_rotation_ : " + z_axis_rotation_ +
                    //"\n extra_axes_positions_[0] : " + extra_axes_positions_[0] +
                    //"\n extra_axes_positions_[1] : " + extra_axes_positions_[1] +
                    //"\n pov_directions_[0] : " + pov_directions_[0] +
                    //"\n pov_directions_[1] : " + pov_directions_[1] +
                    //"\n pov_directions_[2] : " + pov_directions_[2] +
                    //"\n pov_directions_[3] : " + pov_directions_[3] +
                    //"\n buttons_[0] : " + buttons_[0] +
                    //"\n buttons_[1] : " + buttons_[1] +
                    //"\n buttons_[2] : " + buttons_[2]; 
                   "\n Manual";
            }
            else
            {
                return "\n x_axis_position_ : " + x_axis_position_ +
                       "\n y_axis_position_ : " + y_axis_position_ +
                    //"\n Z_axis_position_ : " + z_axis_position_ +
                    //"\n x_axis_rotation_ : " + x_axis_rotation_ +
                    //"\n y_axis_rotation_ : " + y_axis_rotation_ +
                    //"\n z_axis_rotation_ : " + z_axis_rotation_ +
                    //"\n extra_axes_positions_[0] : " + extra_axes_positions_[0] +
                    //"\n extra_axes_positions_[1] : " + extra_axes_positions_[1] +
                    //"\n pov_directions_[0] : " + pov_directions_[0] +
                    //"\n pov_directions_[1] : " + pov_directions_[1] +
                    //"\n pov_directions_[2] : " + pov_directions_[2] +
                    //"\n pov_directions_[3] : " + pov_directions_[3] +
                    //"\n buttons_[0] : " + buttons_[0] +
                    //"\n buttons_[1] : " + buttons_[1] +
                    //"\n buttons_[2] : " + buttons_[2]; 
                     "\n UNKNOWN";
            }
  
         }

        public object Clone()
        {
            return this.MemberwiseClone();
        }

    }

}
