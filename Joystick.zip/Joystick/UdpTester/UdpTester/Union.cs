﻿using System;
using System.IO;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.InteropServices;

namespace UdpTester
{
    public static class Union
    {
        public enum Endianness
        {
            BigEndian,
            LittleEndian
        }

        internal static void BytesToClass<T>(byte[] rawData, Endianness endianness, ref T aObject) where T : class ,ICloneable
        {
            AdjustEndianness(typeof(T), rawData, endianness);
            GCHandle pinnedPacket = GCHandle.Alloc(rawData, GCHandleType.Pinned);
            try
            {
                Marshal.PtrToStructure(pinnedPacket.AddrOfPinnedObject(), aObject);
            }
            finally
            {
                pinnedPacket.Free();
            }
        }

        internal static void ClassToBytes<T>(ref byte[] data, Endianness endianness, T aObject) where T : class, ICloneable
        {
            byte[] rawData = new byte[Marshal.SizeOf(aObject)];
            GCHandle handle = GCHandle.Alloc(rawData, GCHandleType.Pinned);
            try
            {
                IntPtr rawDataPtr = handle.AddrOfPinnedObject();
                Marshal.StructureToPtr(aObject, rawDataPtr, false);
            }
            finally
            {
                handle.Free();
            }

            AdjustEndianness(typeof(T), rawData, endianness);
            data = rawData;
        }

        internal static T BytesToStruct<T>(byte[] rawData, Endianness endianness) where T : struct
        {
            T result = default(T);

            AdjustEndianness(typeof(T), rawData, endianness);

            GCHandle handle = GCHandle.Alloc(rawData, GCHandleType.Pinned);

            try
            {
                IntPtr rawDataPtr = handle.AddrOfPinnedObject();
                result = (T)Marshal.PtrToStructure(rawDataPtr, typeof(T));
            }
            finally
            {
                handle.Free();
            }

            return result;
        }

        internal static byte[] StructToBytes<T>(T data, Endianness endianness) where T : struct
        {
            byte[] rawData = new byte[Marshal.SizeOf(data)];
            GCHandle handle = GCHandle.Alloc(rawData, GCHandleType.Pinned);
            try
            {
                IntPtr rawDataPtr = handle.AddrOfPinnedObject();
                Marshal.StructureToPtr(data, rawDataPtr, false);
            }
            finally
            {
                handle.Free();
            }

            AdjustEndianness(typeof(T), rawData, endianness);

            return rawData;
        }


        private static void AdjustEndianness(Type type, byte[] data, Endianness endianness, int startOffset = 0)
        {
            if ((BitConverter.IsLittleEndian) == (endianness == Endianness.LittleEndian))
            {
                // nothing to change => return
                return;
            }

            foreach (var field in type.GetFields())
            {
                var fieldType = field.FieldType;
                if (field.IsStatic)
                    // don't process static fields
                    continue;

                if (fieldType == typeof(string))
                    // don't swap bytes for strings
                    continue;

                var offset = Marshal.OffsetOf(type, field.Name).ToInt32();

                // check for sub-fields to recurse if necessary
                var subFields = fieldType.GetFields().Where(subField => subField.IsStatic == false).ToArray();

                var effectiveOffset = startOffset + offset;

                if (subFields.Length == 0)
                {
                    Array.Reverse(data, effectiveOffset, Marshal.SizeOf(fieldType));
                }
                else
                {
                    // recurse
                    AdjustEndianness(fieldType, data, endianness, effectiveOffset);
                }
            }
        }
        public static void ChangeEndianness(Type type, byte[] data, int offSet = 0)
        {
            var fields = type.GetFields()
                .Select(f => new
                {
                    Field = f,
                    Offset = Marshal.OffsetOf(type, f.Name).ToInt32(),
                }).ToList();

            foreach (var field in fields)
            {
                if (field.Field.FieldType.IsArray)
                {
                    //handle arrays, assuming fixed length
                    var attr = field.Field.GetCustomAttributes(typeof(MarshalAsAttribute), false).FirstOrDefault();
                    var marshalAsAttribute = attr as MarshalAsAttribute;
                    if (marshalAsAttribute == null || marshalAsAttribute.SizeConst == 0)
                        throw new NotSupportedException(
                            "Array fields must be decorated with a MarshalAsAttribute with SizeConst specified.");

                    var arrayLength = marshalAsAttribute.SizeConst;
                    var elementType = field.Field.FieldType.GetElementType();
                    var elementSize = Marshal.SizeOf(elementType);

                    for (int i = field.Offset + offSet; i < elementSize * arrayLength; i += elementSize)
                    {
                        ChangeEndianness(elementType, data, i);
                    }
                }
                else if (!field.Field.FieldType.IsPrimitive) //or !field.Field.FiledType.GetFields().Length == 0
                {
                    //handle nested structs
                    ChangeEndianness(field.Field.FieldType, data, field.Offset);
                }
                else
                {
                    //handle primitive types
                    Array.Reverse(data, offSet + field.Offset, Marshal.SizeOf(field.Field.FieldType));
                }
            }

        }
        public static T gDeepClone<T>(this T source)
        {
            if (!typeof(T).IsSerializable)
            {
                throw new ArgumentException("The type must be serializable.", "source");
            }

            if (Object.ReferenceEquals(source, null))
            {
                return default(T);
            }

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new MemoryStream();
            using (stream)
            {
                formatter.Serialize(stream, source);
                stream.Seek(0, SeekOrigin.Begin);
                return (T)formatter.Deserialize(stream);
            }
        }

    }


}
