﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UdpTester
{
    class UDPTester
    {
        static void Main(string[] args)
        {
            // 
            UDPClient udp_client = new UDPClient("127.0.0.1", 50500, "127.0.0.1", 50010);

            while (true)
            {
                udp_client.UDPReceiveMessage();
            }

        }
    }
}
