﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

using System.Runtime.InteropServices;

namespace UdpTester
{
    class UDPClient
    {

        private IPEndPoint local_ip_receive_;
        private IPEndPoint remote_ip_send_;

        private UdpClient udpClientReceive;

        public UDPClient(string asLocalIP, int aiLocalPort, string asRemoteIP, int aiRemotePort)
        {
        
            remote_ip_send_ = new IPEndPoint(IPAddress.Parse(asRemoteIP), aiRemotePort);
            local_ip_receive_ = new IPEndPoint(IPAddress.Parse(asLocalIP), aiRemotePort);
            
        }

        public bool UDPReceiveMessage()
        {
            try
            {
                udpClientReceive = new UdpClient(local_ip_receive_);
                byte[] buffer = new byte[80];
                buffer = udpClientReceive.Receive(ref remote_ip_send_);


                // For Sara
                SafetyCamMessage safe_cam_message = new SafetyCamMessage();
                safe_cam_message.FromByteArray(buffer);



                // 

                // Convert the buffer to struct
                //JoystickMessage joystick_message = new JoystickMessage();
                //Union.BytesToClass<JoystickMessage>(buffer, Union.Endianness.BigEndian, ref joystick_message);

                //Console.WriteLine(joystick_message);

                udpClientReceive.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {

            }
        }


        public void Dispose()
        {
            udpClientReceive.Close();
        }
      
    }

}
