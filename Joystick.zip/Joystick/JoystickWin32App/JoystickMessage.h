
#ifndef JoystickMessage_H
#define JoystickMessage_H


#include <string>
#include <algorithm>
#include "CommMessage.h"
class JoystickInterface;

class JoystickMessage : public CommMessage {
    ////    Operations    ////
    
public :

	enum JOYSTICK_MODE {
		AUTO = 0,
		MANUAL = 1
	};

	struct JoystickMessageParams {
	public:
		long x_axis_position_;                     /* x-axis position              */
		long y_axis_position_;                     /* y-axis position              */
		//long z_axis_position_;                     /* z-axis position              */
		//long x_axis_rotation_;                    /* x-axis rotation              */
		//long y_axis_rotation_;                    /* y-axis rotation              */
		//long z_axis_rotation_;                    /* z-axis rotation              */
		//long extra_axes_positions_[2];           /* extra axes positions         */
		//unsigned long pov_directions_[4];             /* POV directions               */
		//unsigned char buttons_[32];         /* 32 buttons                   */
		int last_pressed_button;
		JOYSTICK_MODE joystick_mode;
	};


	void CreateMessage(long x_axis_position,
		long y_axis_position,
		long z_axis_position,
		long x_axis_rotation,
		long y_axis_rotation,
		long z_axis_rotation,
		long extra_axes_positions[2],
		unsigned long pov_directions[4],
		unsigned char buttons[32],
		int &last_pressed_button,
		int auto_button,
		int manual_button);



	JoystickMessageParams joystick_message_params_;
};

#endif
//////////////////////////////////////////////////////////////////////
//      Module Element	: JoystickMessage
//////////////////////////////////////////////////////////////////////
