

#include "DirectXInterface.h"




LPDIRECTINPUT8 DirectXInterface::direct_input_ = NULL;
HRESULT DirectXInterface::result_ = E_FAIL;
LPDIRECTINPUTDEVICE8 DirectXInterface::joystick_ = NULL;

BOOL CALLBACK DirectXInterface::EnumCallback(const DIDEVICEINSTANCE* instance, VOID* context)
{

	// Obtain an interface to the enumerated joystick.
	result_ = direct_input_->CreateDevice(instance->guidInstance, &joystick_, NULL);

	// If it failed, then we can't use this joystick. (Maybe the user unplugged
	// it while we were in the middle of enumerating it.)
	if (FAILED(result_)) { 
		return DIENUM_CONTINUE;
	}

	// Stop enumeration. Note: we're just taking the first joystick we get. You
	// could store all the enumerated joysticks and let the user pick.
	return DIENUM_STOP;
}
BOOL CALLBACK DirectXInterface::EnumAxesCallback(const DIDEVICEOBJECTINSTANCE* instance, VOID* context)
{

	HWND hDlg = (HWND)context;



	DIPROPRANGE propRange; 
	propRange.diph.dwSize       = sizeof(DIPROPRANGE); 
	propRange.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	propRange.diph.dwHow        = DIPH_BYID; 
	propRange.diph.dwObj        = instance->dwType;
	propRange.lMin              = -1000; 
	propRange.lMax              = +1000; 

	// Set the range for the axis
	if (FAILED(joystick_->SetProperty(DIPROP_RANGE, &propRange.diph))) {
		return DIENUM_STOP;
	}

	// Set the UI to reflect what objects the joystick supports

	static int nSliderCount = 0;  // Number of returned slider controls
	static int nPOVCount = 0;     // Number of returned POV controls

	if( instance->guidType == GUID_XAxis )
	{
		EnableWindow( GetDlgItem( hDlg, IDC_X_AXIS ), TRUE );
		EnableWindow( GetDlgItem( hDlg, IDC_X_AXIS_TEXT ), TRUE );
	}
	if( instance->guidType == GUID_YAxis )
	{
		EnableWindow( GetDlgItem( hDlg, IDC_Y_AXIS ), TRUE );
		EnableWindow( GetDlgItem( hDlg, IDC_Y_AXIS_TEXT ), TRUE );
	}
	if( instance->guidType == GUID_ZAxis )
	{
		EnableWindow( GetDlgItem( hDlg, IDC_Z_AXIS ), TRUE );
		EnableWindow( GetDlgItem( hDlg, IDC_Z_AXIS_TEXT ), TRUE );
	}
	if( instance->guidType == GUID_RxAxis )
	{
		EnableWindow( GetDlgItem( hDlg, IDC_X_ROT ), TRUE );
		EnableWindow( GetDlgItem( hDlg, IDC_X_ROT_TEXT ), TRUE );
	}
	if( instance->guidType == GUID_RyAxis )
	{
		EnableWindow( GetDlgItem( hDlg, IDC_Y_ROT ), TRUE );
		EnableWindow( GetDlgItem( hDlg, IDC_Y_ROT_TEXT ), TRUE );
	}
	if( instance->guidType == GUID_RzAxis )
	{
		EnableWindow( GetDlgItem( hDlg, IDC_Z_ROT ), TRUE );
		EnableWindow( GetDlgItem( hDlg, IDC_Z_ROT_TEXT ), TRUE );
	}
	if( instance->guidType == GUID_Slider )
	{
		switch( nSliderCount++ )
		{
		case 0 :
			EnableWindow( GetDlgItem( hDlg, IDC_SLIDER0 ), TRUE );
			EnableWindow( GetDlgItem( hDlg, IDC_SLIDER0_TEXT ), TRUE );
			break;

		case 1 :
			EnableWindow( GetDlgItem( hDlg, IDC_SLIDER1 ), TRUE );
			EnableWindow( GetDlgItem( hDlg, IDC_SLIDER1_TEXT ), TRUE );
			break;
		}
	}
	if( instance->guidType == GUID_POV )
	{
		switch( nPOVCount++ )
		{
		case 0 :
			EnableWindow( GetDlgItem( hDlg, IDC_POV0 ), TRUE );
			EnableWindow( GetDlgItem( hDlg, IDC_POV0_TEXT ), TRUE );
			break;

		case 1 :
			EnableWindow( GetDlgItem( hDlg, IDC_POV1 ), TRUE );
			EnableWindow( GetDlgItem( hDlg, IDC_POV1_TEXT ), TRUE );
			break;

		case 2 :
			EnableWindow( GetDlgItem( hDlg, IDC_POV2 ), TRUE );
			EnableWindow( GetDlgItem( hDlg, IDC_POV2_TEXT ), TRUE );
			break;

		case 3 :
			EnableWindow( GetDlgItem( hDlg, IDC_POV3 ), TRUE );
			EnableWindow( GetDlgItem( hDlg, IDC_POV3_TEXT ), TRUE );
			break;
		}
	}



	return DIENUM_CONTINUE;
}


bool DirectXInterface::PollJoystick() {
	// Polling from joystick
	
	HRESULT hr;



	if( NULL == joystick_ )
		return false;

	// Poll the device to read the current state

	hr = joystick_->Poll();
	if( FAILED( hr ) )
	{
		// DInput is telling us that the input stream has been
		// interrupted. We aren't tracking any state between polls, so
		// we don't have any special reset that needs to be done. We
		// just re-acquire and try again.
		hr = joystick_->Acquire();
		while( hr == DIERR_INPUTLOST)
			hr = joystick_->Acquire();

		// hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
		// may occur when the app is minimized or in the process of 
		// switching, so just try again later 

		// If we encounter a fatal error, return failure.
		if ((hr == DIERR_INVALIDPARAM) || (hr == DIERR_NOTINITIALIZED)) {
			return false;
		}

		// If another application has control of this device, return successfully.
		// We'll just have to wait our turn to use the joystick.
		if (hr == DIERR_OTHERAPPHASPRIO) {
			return true;
		}
	}

	if(!GetDeviceState()) {
		return false;
	}

	return true;

}

bool DirectXInterface::GetDeviceState() {

	// Display joystick state to dialog
	// Get the input's device state
	if (FAILED(result_ = joystick_->GetDeviceState(sizeof(DIJOYSTATE2), &joystick_state_))) {
		return false; // The device should have been acquired during the Poll()
	}

	return true;
}



bool DirectXInterface::CloseJoystick() {
	// Closing the Joystick
	// When you're done using the joystick, you should close the device.
	if (joystick_) { 
		joystick_->Unacquire();
		joystick_->Release();
	}

	if(direct_input_) {
	  direct_input_->Release();
	}

	return true;

}

void DirectXInterface::CreateJoystickMessage() {
   
	joystick_message_->CreateMessage(joystick_state_.lX,
		                             joystick_state_.lY,
									 joystick_state_.lZ,
									 joystick_state_.lRx,
									 joystick_state_.lRy,
									 joystick_state_.lRz,
									 joystick_state_.rglSlider,
									 joystick_state_.rgdwPOV,
									 joystick_state_.rgbButtons,
									 last_pressed_button_,
									 auto_button_,
									 manual_button_);
	
}

void DirectXInterface::SendJoystickMessage() {
    

   // Only for debug - Need to remove
   // ********************************************
	/*
	joystick_message_->joystick_message_params_.x_axis_position_ = 3;
	joystick_message_->joystick_message_params_.y_axis_position_ = 5;
	joystick_message_->joystick_message_params_.z_axis_position_ = 7;

	joystick_message_->joystick_message_params_.x_axis_rotation_ = 2;
	joystick_message_->joystick_message_params_.y_axis_rotation_ = 4;
	joystick_message_->joystick_message_params_.z_axis_rotation_ = 6;

	for(int i = 0 ; i < 2 ; i++) {
		joystick_message_->joystick_message_params_.extra_axes_positions_[i] = i;
	}

	for(int i = 0 ; i < 4 ; i++) {
		joystick_message_->joystick_message_params_.pov_directions_[i] = i;
	}

	for(int i = 0 ; i < 32 ; i++) {
		joystick_message_->joystick_message_params_.buttons_[i] = 'f';
	}
	*/
   // ******************************************* 

   comm_interface_->Send((char*)(&(joystick_message_->joystick_message_params_)), sizeof(JoystickMessage::JoystickMessageParams));
}


DirectXInterface::DirectXInterface(char *remote_ip,
	int remote_port,
	char *local_ip,
	int local_port,
	int auto_button,
	int manual_button) {
	
	auto_button_ = auto_button;
	manual_button_ = manual_button;
	last_pressed_button_ = 0;

	comm_interface_ = new UdpCom();
	comm_interface_->Init(remote_ip, remote_port , local_ip, local_port);
	
	joystick_message_ = new JoystickMessage();
}

DirectXInterface::~DirectXInterface() {
	CloseJoystick();
}
bool DirectXInterface::InitJoystick(HWND hDlg) {
	
	InitCommonControls();

	HRESULT hr;

	// Register with the DirectInput subsystem and get a pointer
	// to a IDirectInput interface we can use.
	// Create a DInput object
	if( FAILED( hr = DirectInput8Create( GetModuleHandle( NULL ), DIRECTINPUT_VERSION,
		IID_IDirectInput8, ( VOID** )&direct_input_, NULL ) ) )
		return false;

	struct DI_ENUM_CONTEXT
	{
		DIJOYCONFIG* pPreferredJoyCfg;
		bool bPreferredJoyCfgValid;
	};
	

	DIJOYCONFIG PreferredJoyCfg = {0};
	DI_ENUM_CONTEXT enumContext;
	enumContext.pPreferredJoyCfg = &PreferredJoyCfg;
	enumContext.bPreferredJoyCfgValid = false;

	IDirectInputJoyConfig8* pJoyConfig = NULL;
	if( FAILED( hr = direct_input_->QueryInterface( IID_IDirectInputJoyConfig8, ( void** )&pJoyConfig ) ) )
		return false;

	PreferredJoyCfg.dwSize = sizeof( PreferredJoyCfg );
	if( SUCCEEDED( pJoyConfig->GetConfig( 0, &PreferredJoyCfg, DIJC_GUIDINSTANCE ) ) ) // This function is expected to fail if no joystick is attached
		enumContext.bPreferredJoyCfgValid = true;
	

	// Look for a simple joystick we can use for this sample program.
	if( FAILED( hr = direct_input_->EnumDevices( DI8DEVCLASS_GAMECTRL,
		DirectXInterface::EnumCallback,
		&enumContext, DIEDFL_ATTACHEDONLY ) ) )
		return false;


	// Make sure we got a joystick
	if( NULL == joystick_ )
	{
		return false;
	}

	// Set the data format to "simple joystick" - a predefined data format 
	//
	// A data format specifies which controls on a device we are interested in,
	// and how they should be reported. This tells DInput that we will be
	// passing a DIJOYSTATE2 structure to IDirectInputDevice::GetDeviceState().
	if( FAILED( hr = joystick_->SetDataFormat( &c_dfDIJoystick2 ) ) )
		return false;

	// Set the cooperative level to let DInput know how this device should
	// interact with the system and with other DInput applications.

	if( FAILED( hr = joystick_->SetCooperativeLevel( hDlg, DISCL_EXCLUSIVE |
		DISCL_BACKGROUND ) ) )
		return false;

	// Enumerate the joystick objects. The callback function enabled user
	// interface elements for objects that are found, and sets the min/max
	// values property for discovered axes.
	if( FAILED( hr = joystick_->EnumObjects(DirectXInterface::EnumAxesCallback,
		( VOID* )hDlg, DIDFT_ALL ) ) )
		return false;



	return true;
}


//////////////////////////////////////////////////////////////////////
//      Module Element	: DirectXInterface
//////////////////////////////////////////////////////////////////////
