
#ifndef CommInterface_H
#define CommInterface_H


class CommMessage;

class CommInterface {
    
public:
	virtual bool Init(char * remote_ip,
		              int remote_port,
					  char * local_ip,
					  int local_port) = 0;
	virtual bool Send(char *buf , int buf_size) = 0;
	virtual bool SetRemoteParameters(char * ip, int port) = 0;
	virtual bool Close() = 0;
};

#endif
//////////////////////////////////////////////////////////////////////
//      Module Element	: CommInterface
//////////////////////////////////////////////////////////////////////
