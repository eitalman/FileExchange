#pragma once
#ifndef UdpCom_H
#define UdpCom_H

#include<stdio.h>
#include<winsock2.h>


#pragma comment(lib, "ws2_32.lib") // winsocket library


#include "CommInterface.h"


class UdpCom : public CommInterface {
public:	
	virtual bool Init(char * remote_ip,
		              int remote_port,
					  char * local_ip,
					  int local_port);
	virtual bool Send(char *buf , int buf_size);
	virtual bool SetRemoteParameters(char * ip, int port);
	virtual bool Close();

private:
	SOCKET s;
	struct sockaddr_in server, si_other;
};

#endif
//////////////////////////////////////////////////////////////////////
//      Module Element	: UdpCom
//////////////////////////////////////////////////////////////////////
