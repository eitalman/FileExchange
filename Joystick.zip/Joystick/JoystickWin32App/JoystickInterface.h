
#ifndef JoystickInterface_H
#define JoystickInterface_H


#include <windows.h>
#include <string>
#include <algorithm>

class CommInterface;
class JoystickMessage;

class JoystickInterface {
    ////    Operations    ////
    
public :

	virtual bool InitJoystick(HWND hDlg) = 0;

	virtual bool PollJoystick() = 0;

	virtual bool GetDeviceState() = 0;

	virtual bool CloseJoystick() = 0;

	virtual void CreateJoystickMessage() = 0;

	virtual void SendJoystickMessage() = 0;

	JoystickMessage* joystick_message_;

protected:


	CommInterface* comm_interface_;
};

#endif
//////////////////////////////////////////////////////////////////////
//      Module Element	: JoystickInterface
//////////////////////////////////////////////////////////////////////
