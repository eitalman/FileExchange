
#include "JoystickMessage.h"

#include "JoystickInterface.h"


void JoystickMessage::CreateMessage(long x_axis_position,
									long y_axis_position,
									long z_axis_position,
									long x_axis_rotation,
									long y_axis_rotation,
									long z_axis_rotation,
									long extra_axes_positions[2],
									unsigned long pov_directions[4],
									unsigned char buttons[32],
									int &last_pressed_button,
									int auto_button,
									int manual_button) {

    
	joystick_message_params_.x_axis_position_ = x_axis_position;
	joystick_message_params_.y_axis_position_ = y_axis_position;
	//joystick_message_params_.z_axis_position_ = z_axis_position;

    //joystick_message_params_.x_axis_rotation_ = x_axis_rotation;
	//joystick_message_params_.y_axis_rotation_ = y_axis_rotation;
	//joystick_message_params_.z_axis_rotation_ = z_axis_rotation;

	/*for(int i = 0 ; i < 2 ; i++) {
      joystick_message_params_.extra_axes_positions_[i] = extra_axes_positions[i];
	}*/


    /*for(int i = 0 ; i < 4 ; i++) {
	  joystick_message_params_.pov_directions_[i] = pov_directions[i];
	}*/
	int pressed_button = 0;
	int number_of_pressed_buttons = 0;

	for(int i = 0 ; i < 32 ; i++) {

		if(buttons[i] != 0) {

			if ((i+1 != auto_button) && (i+1 != manual_button)) {
				continue;
			}

			number_of_pressed_buttons++;
			pressed_button = i+1;
		}
		if(number_of_pressed_buttons > 1) {
			break;
		}
		//joystick_message_params_.buttons_[i] = buttons[i];
	}
	if(number_of_pressed_buttons == 1) {
	  // Convert the pressed button to our enum
	  if(pressed_button == auto_button) {
		joystick_message_params_.last_pressed_button = AUTO;
		last_pressed_button = AUTO;
	  } else if(pressed_button == manual_button) {
		  joystick_message_params_.last_pressed_button = MANUAL;
		  last_pressed_button = MANUAL;
	  }
	} else {
      joystick_message_params_.last_pressed_button = last_pressed_button;
	}
}



//////////////////////////////////////////////////////////////////////
//      Module Element	: JoystickMessage
//////////////////////////////////////////////////////////////////////
