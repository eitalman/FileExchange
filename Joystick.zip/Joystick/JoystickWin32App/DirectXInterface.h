#ifndef DirectXInterface_H
#define DirectXInterface_H

#include "UdpCom.h"
#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <commctrl.h>
#include <basetsd.h>
#include <string>
#include <algorithm>
#include <dinput.h>
#include <dinputd.h>
#include <assert.h>
#include <oleauto.h>
#include <shellapi.h>
#include "resource.h"
#include "JoystickMessage.h"
#include "JoystickInterface.h"



class JoystickMessage;

class DirectXInterface : public JoystickInterface {
public :

	DirectXInterface(char *remote_ip,
	int remote_port,
	char *local_ip,
	int local_port,
	int auto_button,
	int manual_button);

	~DirectXInterface();


	virtual bool InitJoystick(HWND hDlg);

	virtual bool PollJoystick();

	virtual bool GetDeviceState();

	virtual bool CloseJoystick();

	virtual void CreateJoystickMessage();

	virtual void SendJoystickMessage();


	// Static functions
	static  BOOL CALLBACK EnumCallback(const DIDEVICEINSTANCE* instance, VOID* context);
	static  BOOL CALLBACK EnumAxesCallback(const DIDEVICEOBJECTINSTANCE* instance, VOID* context);

	DIJOYSTATE2 GetJoystickState() {
		return joystick_state_;
	}

	void Acquire() {
		if(joystick_) {
			 joystick_->Acquire();
		}
	}

	void UnAcquire() {
		if(joystick_) {
			joystick_->Unacquire();
			joystick_->Release();
			direct_input_->Release();
		}

	}


public:
	static LPDIRECTINPUT8 direct_input_;
	static HRESULT result_;
	static LPDIRECTINPUTDEVICE8 joystick_;


private:
	// Joystick Properties
	DIDEVCAPS capabilities_;
    DIJOYSTATE2 joystick_state_;

	int last_pressed_button_;
	int auto_button_;
    int manual_button_;
};

#endif
//////////////////////////////////////////////////////////////////////
//      Module Element	: DirectXInterface
//////////////////////////////////////////////////////////////////////
