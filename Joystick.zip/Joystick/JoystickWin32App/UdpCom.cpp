#include "UdpCom.h"

bool UdpCom::Init(char * remote_ip,
	int remote_port,
	char * local_ip,
	int local_port)
{
	
	

	int slen;
	WSADATA wsa;

	slen = sizeof(si_other) ;

	//Initialize winsock
	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
	{
		printf("Failed. Error Code : %d",WSAGetLastError());
		exit(EXIT_FAILURE);
	}
	printf("Initialized.\n");

	//Create a socket
	if((s = socket(AF_INET , SOCK_DGRAM , 0 )) == INVALID_SOCKET)
	{
		printf("Could not create socket : %d" , WSAGetLastError());
	}
	printf("Socket created.\n");

	//Prepare the sockaddr_in structure
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(local_ip);
	server.sin_port = htons(local_port);

	//Bind
	if(bind(s ,(struct sockaddr *)&server , sizeof(server)) == SOCKET_ERROR)
	{
		printf("Bind failed with error code : %d" , WSAGetLastError());
		exit(EXIT_FAILURE);
	}
	puts("Bind done");

	SetRemoteParameters(remote_ip, remote_port);

	return true;
}

bool UdpCom::Close() {
	
	closesocket(s);
	WSACleanup();
	
	return true;
}

bool UdpCom::SetRemoteParameters(char * ip, int port) {

	si_other.sin_family = AF_INET;

	// NEED TO READ FROM CONFIGURATION THGE PORT AND THE IP OF THE TARGET
	si_other.sin_addr.s_addr = inet_addr(ip);/*INADDR_ANY;*/
	si_other.sin_port = htons(port);

	return true;
}
bool UdpCom::Send(char *buf , int buf_size) {

	int slen;
	slen = sizeof(si_other) ;

	//now reply the client with the same dataremote_ip_receive_
	if (sendto(s, buf, buf_size, 0, (struct sockaddr*) &si_other, slen) == SOCKET_ERROR)
	{
		printf("sendto() failed with error code : %d" , WSAGetLastError());
		return false;
	}

	puts("Message Sent");

	return true;
}


//////////////////////////////////////////////////////////////////////
//      Module Element	: UdpCom
//////////////////////////////////////////////////////////////////////
